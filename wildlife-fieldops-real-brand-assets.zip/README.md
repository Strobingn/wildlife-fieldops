# Wildlife FieldOps Real Brand Assets

Use these files in your repo:

assets/logo.png
assets/splash.png
assets/monochrome.svg

GitHub Actions should run:

npx capacitor-assets generate --android

Recommended workflow step:

- name: Generate Icons + Splash Assets
  run: npx capacitor-assets generate --android

These PNG files are cropped from the concept sheet, so they look much closer to the generated image than a hand-coded SVG.
