import { supabase } from "./auth/supabaseClient.js";
import { runFieldAI, formatFieldAIResult } from "./ai/fieldAssistant.js";
import { Geolocation } from "@capacitor/geolocation";
import { jsPDF } from "jspdf";
import { KEYS } from "./config.js";

/* ─── API KEYS (env vars preferred, fallback to config.js) ─── */
const GOOGLE_MAPS_API_KEY = import.meta.env?.VITE_GOOGLE_MAPS_API_KEY || KEYS.GOOGLE_MAPS;
const GOOGLE_CALENDAR_CLIENT_ID = import.meta.env?.VITE_GOOGLE_CALENDAR_CLIENT_ID || KEYS.GOOGLE_CALENDAR_CLIENT_ID;
const OPENWEATHER_API_KEY = import.meta.env?.VITE_OPENWEATHER_API_KEY || KEYS.OPENWEATHER;
const GOOGLE_API_KEY = import.meta.env?.VITE_GOOGLE_API_KEY || KEYS.GOOGLE_API_KEY;

/* ─── CONSTANTS ─── */
const SERVICES = [
  { name: "Inspection", price: 125 },
  { name: "Inspection photography", price: 75 },
  { name: "One-way set / one-way door", price: 225 },
  { name: "Bird gel", price: 125 },
  { name: "Sheet metal work", price: 35 },
  { name: "Caulking", price: 12 },
  { name: "Stainless steel mesh", price: 45 },
  { name: "Hardware cloth", price: 35 },
  { name: "Exclusion repair", price: 150 },
  { name: "Soffit / fascia repair", price: 225 },
  { name: "Ridge vent guard", price: 300 },
  { name: "Chimney cap", price: 350 },
  { name: "Gable vent screening", price: 175 },
  { name: "Foundation gap sealing", price: 95 },
  { name: "Cleanup / sanitation", price: 250 },
  { name: "Warranty follow-up", price: 125 }
];

const SPECIES = [
  "Raccoon", "Grey Squirrel", "Red Squirrel", "Flying Squirrel", "Bat", "Skunk",
  "Groundhog", "Bird", "Snake", "Opossum", "Rodent", "Mouse", "Rat", "Carpenter Bee", "Other"
];

const SPECIES_ICONS = {
  "Raccoon": "🦝",
  "Grey Squirrel": "🐿️",
  "Red Squirrel": "🐿️",
  "Flying Squirrel": "🦇",
  "Bat": "🦇",
  "Skunk": "🦨",
  "Groundhog": "🦫",
  "Bird": "🐦",
  "Snake": "🐍",
  "Opossum": "🦡",
  "Rodent": "🐁",
  "Mouse": "🐁",
  "Rat": "🐀",
  "Carpenter Bee": "🐝",
  "Other": "🐾"
};

const STATUS_STYLES = {
  "Active": "active",
  "Scheduled": "scheduled",
  "Closed": "closed",
  "Trapping": "trapping",
  "Repair": "repair",
  "Waiting On Customer": "scheduled",
  "Exclusion": "active",
  "Warranty": "active"
};

/* ─── STATE ─── */
const app = document.getElementById("app");
const menuEl = document.getElementById("menu");
let screen = "dashboard";
let jobs = [];
let techs = [];
let services = [];
let inspections = [];
let photos = [];
let selectedJob = null;
let map = null;
let markers = [];
let gapiLoaded = false;
let gisLoaded = false;
let tokenClient = null;
let searchDebounce = null;

/* ─── UTILS ─── */
function money(n) { return "$" + Number(n || 0).toLocaleString(); }
function esc(v) {
  return String(v || "").replace(/[&<>"']/g, m => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[m]));
}
function go(page) {
  screen = page;
  menuEl.classList.remove("open");
  updateBottomNav(page);
  render();
}
window.go = go;
window.toggleMenu = () => {
  menuEl.classList.toggle("open");
  const backdrop = document.getElementById("menuBackdrop");
  if (backdrop) backdrop.classList.toggle("open", menuEl.classList.contains("open"));
};

function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

function throttle(fn, ms) {
  let last = 0;
  return (...args) => {
    const now = Date.now();
    if (now - last >= ms) { last = now; fn(...args); }
  };
}

/* ─── UI HELPERS ─── */
function showLoading(msg = "Loading…") {
  let ov = document.getElementById("loading-overlay");
  if (!ov) {
    ov = document.createElement("div");
    ov.id = "loading-overlay";
    ov.style.cssText = "position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.6);backdrop-filter:blur(4px);display:none;align-items:center;justify-content:center;flex-direction:column;gap:12px;z-index:9998;color:#fff;font-size:14px;font-family:Inter,sans-serif;";
    ov.innerHTML = `<div style="width:48px;height:48px;border:4px solid rgba(255,255,255,0.2);border-top-color:#22c55e;border-radius:50%;animation:spin 1s linear infinite;"></div><span>${msg}</span>`;
    document.body.appendChild(ov);
    const style = document.createElement("style");
    style.textContent = "@keyframes spin{to{transform:rotate(360deg)}}";
    document.head.appendChild(style);
  } else {
    ov.querySelector("span").textContent = msg;
  }
  ov.style.display = "flex";
}

function hideLoading() {
  const ov = document.getElementById("loading-overlay");
  if (ov) ov.style.display = "none";
}

function showToast(msg, type = "success", duration = 3000) {
  let t = document.getElementById("toast");
  if (!t) {
    t = document.createElement("div");
    t.id = "toast";
    t.style.cssText = "position:fixed;bottom:90px;left:50%;transform:translateX(-50%);padding:12px 20px;border-radius:12px;font-size:14px;font-weight:500;z-index:10000;opacity:0;transition:opacity 0.3s ease;pointer-events:none;box-shadow:0 4px 12px rgba(0,0,0,0.3);font-family:Inter,sans-serif;";
    document.body.appendChild(t);
  }
  const colors = {
    success: "background:rgba(34,197,94,0.95);color:#fff;",
    error: "background:rgba(239,68,68,0.95);color:#fff;",
    warn: "background:rgba(251,191,36,0.95);color:#000;"
  };
  t.style.cssText = "position:fixed;bottom:90px;left:50%;transform:translateX(-50%);padding:12px 20px;border-radius:12px;font-size:14px;font-weight:500;z-index:10000;opacity:0;transition:opacity 0.3s ease;pointer-events:none;box-shadow:0 4px 12px rgba(0,0,0,0.3);font-family:Inter,sans-serif;" + (colors[type] || colors.success);
  t.textContent = msg;
  requestAnimationFrame(() => { t.style.opacity = "1"; });
  setTimeout(() => { t.style.opacity = "0"; }, duration);
}

/* ─── THEME ─── */
function initTheme() {
  const saved = localStorage.getItem("ww_theme") || "dark";
  document.documentElement.setAttribute("data-theme", saved);
}
window.toggleTheme = function () {
  const html = document.documentElement;
  const current = html.getAttribute("data-theme") || "dark";
  const next = current === "dark" ? "light" : "dark";
  html.setAttribute("data-theme", next);
  localStorage.setItem("ww_theme", next);
  showToast(next === "dark" ? "Dark mode enabled" : "Light mode enabled", "success", 2000);
};

/* ─── MODAL ─── */
window.openModal = function (title, content) {
  const backdrop = document.getElementById("modalBackdrop");
  document.getElementById("modalTitle").textContent = title;
  document.getElementById("modalBody").innerHTML = content;
  backdrop.classList.add("open");
  document.body.style.overflow = "hidden";
};
window.closeModal = function () {
  const backdrop = document.getElementById("modalBackdrop");
  backdrop.classList.remove("open");
  document.body.style.overflow = "";
};
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });

/* ─── SCROLL REVEAL ─── */
function setupReveal() {
  const reveals = document.querySelectorAll(".reveal");
  if (!reveals.length) return;
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  reveals.forEach(el => obs.observe(el));
}

/* ─── ANIMATED COUNTERS ─── */
function animateCounter(el, target, duration = 1200) {
  const start = performance.now();
  const from = 0;
  function step(now) {
    const progress = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    const current = Math.floor(from + (target - from) * eased);
    el.textContent = current.toLocaleString();
    if (progress < 1) requestAnimationFrame(step);
    else el.textContent = target.toLocaleString();
  }
  requestAnimationFrame(step);
}

/* ─── ALERTS ─── */
window.showAlert = function (msg, type = "error", containerId = "alertBox") {
  const box = document.getElementById(containerId);
  if (!box) return;
  const alert = document.createElement("div");
  alert.className = `alert ${type}`;
  alert.innerHTML = `<span>${esc(msg)}</span><button class="alert-dismiss" onclick="this.parentElement.remove()">&times;</button>`;
  box.appendChild(alert);
};

/* ─── FAB SCROLL HIDE/SHOW ─── */
function setupFabScroll() {
  const fab = document.querySelector(".fab");
  if (!fab) return;
  let lastScroll = 0;
  window.addEventListener("scroll", throttle(() => {
    const current = window.scrollY || document.documentElement.scrollTop;
    if (current > lastScroll && current > 100) fab.classList.add("hidden-fab");
    else fab.classList.remove("hidden-fab");
    lastScroll = current;
  }, 150), { passive: true });
}

/* ─── RIPPLE EFFECT ─── */
function setupRipple() {
  document.addEventListener("click", e => {
    const btn = e.target.closest("button.action, button.primary, button.secondary, .quick-action");
    if (!btn) return;
    const circle = document.createElement("span");
    circle.classList.add("ripple-circle");
    const rect = btn.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    circle.style.width = circle.style.height = size + "px";
    circle.style.left = (e.clientX - rect.left - size / 2) + "px";
    circle.style.top = (e.clientY - rect.top - size / 2) + "px";
    btn.appendChild(circle);
    setTimeout(() => circle.remove(), 600);
  });
}

/* ─── VALIDATION ─── */
function isValidPhone(phone) {
  if (!phone) return true;
  const cleaned = phone.replace(/\D/g, "");
  return cleaned.length >= 10 && cleaned.length <= 15;
}

function formatPhone(phone) {
  if (!phone) return "";
  const cleaned = phone.replace(/\D/g, "");
  if (cleaned.length === 10) return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
  if (cleaned.length === 11 && cleaned[0] === "1") return `+1 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7)}`;
  return phone;
}

function validateJob(job) {
  const errors = [];
  if (!job.customer_name || job.customer_name.trim().length < 2) errors.push("Customer name required (min 2 chars)");
  if (!job.address || job.address.trim().length < 5) errors.push("Address required (min 5 chars)");
  if (job.phone && !isValidPhone(job.phone)) errors.push("Invalid phone number");
  if (job.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(job.email)) errors.push("Invalid email");
  return errors;
}

function validateTech(tech) {
  const errors = [];
  if (!tech.name || tech.name.trim().length < 2) errors.push("Tech name required (min 2 chars)");
  if (tech.phone && !isValidPhone(tech.phone)) errors.push("Invalid phone number");
  return errors;
}

/* ─── IMAGE COMPRESSION ─── */
async function compressImage(dataUrl, maxWidth = 1200, quality = 0.7) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      let w = img.width, h = img.height;
      if (w > maxWidth) { h = Math.round(h * maxWidth / w); w = maxWidth; }
      canvas.width = w; canvas.height = h;
      canvas.getContext("2d").drawImage(img, 0, 0, w, h);
      resolve(canvas.toDataURL("image/jpeg", quality));
    };
    img.onerror = reject;
    img.src = dataUrl;
  });
}

/* ─── GPS WITH FALLBACK ─── */
async function getCurrentPosition() {
  try {
    if (typeof Geolocation !== "undefined" && Geolocation.getCurrentPosition) {
      const pos = await Geolocation.getCurrentPosition({ enableHighAccuracy: true, timeout: 10000 });
      return { latitude: String(pos.coords.latitude), longitude: String(pos.coords.longitude) };
    }
  } catch (e) { console.warn("Capacitor geolocation failed, trying fallback:", e); }
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) { reject(new Error("Geolocation not supported")); return; }
    navigator.geolocation.getCurrentPosition(
      pos => resolve({ latitude: String(pos.coords.latitude), longitude: String(pos.coords.longitude) }),
      err => reject(err),
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 }
    );
  });
}

/* ─── DATA ─── */
async function loadData() {
  showLoading("Loading data…");
  try {
    const [j, t, s, i, p] = await Promise.all([
      supabase.from("jobs").select("*").order("created_at", { ascending: false }),
      supabase.from("techs").select("*").order("created_at", { ascending: false }),
      supabase.from("services").select("*"),
      supabase.from("inspections").select("*").order("created_at", { ascending: false }),
      supabase.from("photos").select("*").order("created_at", { ascending: false })
    ]);

    jobs = j.data || [];
    techs = t.data || [];
    services = s.data || [];
    inspections = i.data || [];
    photos = p.data || [];

    localStorage.setItem("ww_fieldops_cache", JSON.stringify({
      jobs, techs, services, inspections, photos,
      cachedAt: new Date().toISOString()
    }));
  } catch (err) {
    console.error("Sync failed, using cached data:", err);
    showToast("Offline mode — using cached data", "warn", 4000);
    const cached = JSON.parse(localStorage.getItem("ww_fieldops_cache") || "{}");
    jobs = cached.jobs || [];
    techs = cached.techs || [];
    services = cached.services || [];
    inspections = cached.inspections || [];
    photos = cached.photos || [];
  } finally {
    hideLoading();
  }

  if (selectedJob) selectedJob = jobs.find(x => x.id === selectedJob.id) || selectedJob;
  render();
}

/* ─── GOOGLE MAPS ─── */
function loadGoogleMaps() {
  if (window.google?.maps || GOOGLE_MAPS_API_KEY.includes("YOUR_")) return;
  if (document.querySelector("script[data-maps]")) return;
  const script = document.createElement("script");
  script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places&callback=onGoogleMapsLoaded`;
  script.async = true;
  script.defer = true;
  script.dataset.maps = "true";
  document.head.appendChild(script);
}
window.onGoogleMapsLoaded = function () {
  if (screen === "dashboard" || screen === "detail") render();
};

function initMap(containerId) {
  if (!window.google?.maps || GOOGLE_MAPS_API_KEY.includes("YOUR_")) {
    const el = document.getElementById(containerId);
    if (el) el.innerHTML = '<div class="card tiny">Add Google Maps API key to enable interactive map.</div>';
    return null;
  }
  const defaultCenter = { lat: 40.7128, lng: -74.0060 };
  const m = new google.maps.Map(document.getElementById(containerId), {
    zoom: 12,
    center: defaultCenter,
    mapTypeId: "roadmap",
    styles: [
      { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
      { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
      { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
      { featureType: "administrative.locality", elementType: "labels.text.fill", stylers: [{ color: "#d59563" }] },
      { featureType: "poi", elementType: "labels.text.fill", stylers: [{ color: "#d59563" }] },
      { featureType: "poi.park", elementType: "geometry", stylers: [{ color: "#263c3f" }] },
      { featureType: "poi.park", elementType: "labels.text.fill", stylers: [{ color: "#6b9a76" }] },
      { featureType: "road", elementType: "geometry", stylers: [{ color: "#38414e" }] },
      { featureType: "road", elementType: "geometry.stroke", stylers: [{ color: "#212a37" }] },
      { featureType: "road", elementType: "labels.text.fill", stylers: [{ color: "#9ca5b3" }] },
      { featureType: "road.highway", elementType: "geometry", stylers: [{ color: "#746855" }] },
      { featureType: "road.highway", elementType: "geometry.stroke", stylers: [{ color: "#1f2835" }] },
      { featureType: "road.highway", elementType: "labels.text.fill", stylers: [{ color: "#f3d19c" }] },
      { featureType: "transit", elementType: "geometry", stylers: [{ color: "#2f3948" }] },
      { featureType: "transit.station", elementType: "labels.text.fill", stylers: [{ color: "#d59563" }] },
      { featureType: "water", elementType: "geometry", stylers: [{ color: "#17263c" }] },
      { featureType: "water", elementType: "labels.text.fill", stylers: [{ color: "#515c6d" }] },
      { featureType: "water", elementType: "labels.text.stroke", stylers: [{ color: "#17263c" }] }
    ]
  });
  return m;
}

function renderMap() {
  const container = document.getElementById("dashMap");
  if (!container || !window.google?.maps) return;

  const mappedJobs = jobs.filter(j => j.latitude && j.longitude);
  if (!mappedJobs.length) {
    container.innerHTML = '<div class="card tiny">No GPS jobs yet.</div>';
    return;
  }

  if (!map) map = initMap("dashMap");
  if (!map) return;

  markers.forEach(m => m.setMap(null));
  markers = [];

  const bounds = new google.maps.LatLngBounds();
  mappedJobs.forEach(job => {
    const pos = { lat: parseFloat(job.latitude), lng: parseFloat(job.longitude) };
    const marker = new google.maps.Marker({
      position: pos,
      map,
      title: `${esc(job.species)} - ${esc(job.customer_name)}`,
      animation: google.maps.Animation.DROP
    });
    marker.addListener("click", () => {
      selectedJob = job;
      screen = "detail";
      updateBottomNav("detail");
      render();
    });
    markers.push(marker);
    bounds.extend(pos);
  });

  if (markers.length > 1) map.fitBounds(bounds);
  else if (markers.length === 1) { map.setCenter(markers[0].getPosition()); map.setZoom(15); }
}

function navigateToJob(lat, lng, address) {
  if (!lat || !lng) {
    if (address) {
      window.open(`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(address)}&travelmode=driving`, "_blank");
      return;
    }
    return showToast("No GPS data for this job.", "warn");
  }
  window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&travelmode=driving`, "_blank");
}
window.navigateToJob = navigateToJob;

/* ─── GOOGLE CALENDAR ─── */
function loadGoogleCalendarAPI() {
  if (gapiLoaded || GOOGLE_CALENDAR_CLIENT_ID.includes("YOUR_")) return;

  const gapiScript = document.createElement("script");
  gapiScript.src = "https://apis.google.com/js/api.js";
  gapiScript.onload = () => {
    window.gapi.load("client", async () => {
      await window.gapi.client.init({
        apiKey: GOOGLE_API_KEY,
        discoveryDocs: ["https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest"]
      });
      gapiLoaded = true;
    });
  };
  document.head.appendChild(gapiScript);

  const gisScript = document.createElement("script");
  gisScript.src = "https://accounts.google.com/gsi/client";
  gisScript.onload = () => {
    tokenClient = google.accounts.oauth2.initTokenClient({
      client_id: GOOGLE_CALENDAR_CLIENT_ID,
      scope: "https://www.googleapis.com/auth/calendar.events",
      callback: () => {}
    });
    gisLoaded = true;
  };
  document.head.appendChild(gisScript);
}

window.createCalendarEvent = async function (job) {
  if (!gapiLoaded || !gisLoaded || GOOGLE_CALENDAR_CLIENT_ID.includes("YOUR_")) {
    showToast("Google Calendar not configured.", "warn");
    return;
  }

  return new Promise((resolve) => {
    tokenClient.callback = async (resp) => {
      if (resp.error) { showToast("Auth error: " + resp.error, "error"); resolve(); return; }
      const event = {
        summary: `Wildlife Job: ${job.customer_name} - ${job.species}`,
        description: `Customer: ${job.customer_name}\nPhone: ${job.phone}\nAddress: ${job.address}\nSpecies: ${job.species}\nScope: ${job.notes || ""}`,
        start: { dateTime: new Date().toISOString(), timeZone: "America/New_York" },
        end: { dateTime: new Date(Date.now() + 3600000).toISOString(), timeZone: "America/New_York" },
        location: job.address
      };
      try {
        const response = await window.gapi.client.calendar.events.insert({ calendarId: "primary", resource: event });
        showToast("Event added to calendar!");
      } catch (err) {
        showToast("Failed to create event: " + err.message, "error");
      }
      resolve();
    };
    tokenClient.requestAccessToken({ prompt: "consent" });
  });
};

/* ─── WEATHER ─── */
async function getWeather(lat, lng) {
  if (OPENWEATHER_API_KEY.includes("YOUR_")) return null;
  try {
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lng}&appid=${OPENWEATHER_API_KEY}&units=imperial`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const data = await res.json();
    return {
      temp: Math.round(data.main.temp),
      condition: data.weather[0].main,
      description: data.weather[0].description,
      icon: `https://openweathermap.org/img/wn/${data.weather[0].icon}@2x.png`
    };
  } catch (e) { console.error("Weather error:", e); return null; }
}

/* ─── VOICE COMMANDS ─── */
/* ─── LAZY LOADING ─── */
function lazyLoadImages() {
  const imgs = document.querySelectorAll("img.lazy");
  if (!imgs.length) return;
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        img.src = img.dataset.src;
        img.classList.add("loaded");
        img.classList.remove("lazy");
        obs.unobserve(img);
      }
    });
  });
  imgs.forEach(img => obs.observe(img));
}

/* ─── NAV / SHELL ─── */
function nav() {
  menuEl.innerHTML = `
    <div style="font-weight:700;font-size:18px;margin-bottom:18px;padding-left:4px;">FieldOps</div>
    <button onclick="go('dashboard')">🏠 Dashboard</button>
    <button onclick="go('jobs')">🦝 Jobs</button>
    <button onclick="go('new')">➕ New Job</button>
    <button onclick="go('estimate')">💵 Estimator</button>
    <button onclick="go('techs')">👷 Techs</button>
    <button onclick="go('metrics')">📊 Metrics</button>
    <button onclick="go('ai')">🧠 AI Assistant</button>
    <button onclick="exportData()">💾 Export JSON</button>
    <button onclick="importDataPrompt()">📥 Import JSON</button>
  `;
}

function updateBottomNav(page) {
  const map = { dashboard: 0, jobs: 1, detail: 2, new: 2, estimate: 3, ai: 4 };
  const idx = map[page] ?? -1;
  document.querySelectorAll(".bottom-nav button").forEach((b, i) => {
    b.classList.toggle("active", i === idx);
  });
}

function shell(content) {
  const hasMap = screen === "dashboard";
  const alertCount = jobs.filter(j => j.status === "Active").length;
  app.innerHTML = `
    <div class="top">
      <div>
        <strong style="font-size:16px;">Wildlife Whisperer FieldOps</strong>
        <div class="tiny" style="margin-top:2px;">${esc(screen)}</div>
      </div>
      <div class="sync-indicator" style="gap:8px;">
        ${hasMap ? '<span class="sync-dot"></span><span>Live</span>' : ""}
        <button class="notification-btn" onclick="go('jobs')" title="Active jobs">
          🔔
          <span class="badge">${alertCount > 0 ? alertCount : ""}</span>
        </button>
        <button class="theme-toggle" onclick="toggleTheme()" title="Toggle theme">
          ${document.documentElement.getAttribute("data-theme") === "light" ? "🌙" : "☀️"}
        </button>
        <button class="menuButton" onclick="toggleMenu()">☰</button>
      </div>
    </div>
    <div class="wrap">${content}</div>
    <div class="bottom-nav">
      <button onclick="go('dashboard')" title="Dashboard">🏠</button>
      <button onclick="go('jobs')" title="Jobs">🦝</button>
      <button onclick="go('new')" title="New Job">➕</button>
      <button onclick="go('estimate')" title="Estimate">💵</button>
      <button onclick="go('ai')" title="AI">🧠</button>
    </div>
    <button class="fab" onclick="go('new')" title="New Job">+</button>
  `;
  setTimeout(() => {
    updateBottomNav(screen);
    if (screen === "dashboard") renderMap();
    lazyLoadImages();
    setupReveal();
    setupFabScroll();
    setupRipple();
  }, 50);
}

/* ─── SCORING ─── */
function jobScore(job) {
  const v = inspections.some(i => i.job_id === job.id);
  const p = photos.some(p => p.job_id === job.id);
  const sv = services.filter(s => s.job_id === job.id);
  const s = sv.length > 0;
  return Math.min(100, (v ? 25 : 0) + (p ? 25 : 0) + (s ? 25 : 0) + (job.latitude ? 25 : 0));
}

/* ─── PAGES ─── */
function dashboard() {
  const active = jobs.filter(j => j.status !== "Closed");
  const total = jobs.reduce((sum, j) => sum + Number(j.grand_total || j.estimate || 0), 0);

  shell(`
    <div class="hero reveal">
      <h1>🦝 Wildlife Whisperer</h1>
      <p>Field Operations Dashboard — ${new Date().toLocaleDateString()}</p>
    </div>

    <div id="alertBox"></div>

    <div class="quick-actions reveal delay-1">
      <div class="quick-action ripple" onclick="go('new')">
        ➕<span>New Job</span>
      </div>
      <div class="quick-action ripple" onclick="go('estimate')">
        💵<span>Estimate</span>
      </div>
      <div class="quick-action ripple" onclick="go('techs')">
        👷<span>Techs</span>
      </div>
      <div class="quick-action ripple" onclick="go('metrics')">
        📊<span>Metrics</span>
      </div>
    </div>

    <div class="grid reveal delay-2">
      <div class="card"><div class="stat" data-count="${active.length}">0</div><div class="tiny">Active jobs</div></div>
      <div class="card"><div class="stat" data-count="${jobs.length}">0</div><div class="tiny">Total jobs</div></div>
      <div class="card"><div class="stat" data-count="${techs.length}">0</div><div class="tiny">Techs</div></div>
      <div class="card"><div class="stat" data-count="${Math.round(total)}">$0</div><div class="tiny">Quoted value</div></div>
    </div>

    <div id="dashWeather" style="margin-bottom:12px;"></div>

    <div id="dashMap" style="height:320px;width:100%;border-radius:16px;margin-bottom:18px;border:1px solid var(--border);background:var(--card);"></div>

    <button class="action reveal" onclick="go('new')">➕ Create New Job</button>
    <button class="action dark reveal" onclick="go('estimate')">💵 Smart Estimator</button>

    <h2 style="margin:18px 0 10px">Recent Jobs</h2>
    ${jobs.slice(0, 5).map((j, i) => jobCard(j).replace('class="card job"', `class="card job reveal delay-${(i % 3) + 1}"`)).join("") || `<div class="card reveal">No jobs yet.</div>`}
  `);

  setTimeout(async () => {
    document.querySelectorAll("[data-count]").forEach(el => {
      const target = parseInt(el.dataset.count, 10) || 0;
      const isMoney = el.nextElementSibling?.textContent.includes("value");
      animateCounter(el, target, 1200);
      if (isMoney) {
        const original = el.textContent;
        const check = () => {
          if (el.textContent === target.toLocaleString()) el.textContent = money(target);
          else requestAnimationFrame(check);
        };
        check();
      }
    });

    const jobWithGps = jobs.find(j => j.latitude && j.longitude);
    if (jobWithGps) {
      const weather = await getWeather(jobWithGps.latitude, jobWithGps.longitude);
      const wbox = document.getElementById("dashWeather");
      if (wbox && weather) {
        wbox.innerHTML = `
          <div class="card reveal">
            <div class="weather-card">
              <img src="${weather.icon}" alt="${esc(weather.description)}" style="width:48px;height:48px;">
              <div>
                <div style="font-weight:700;font-size:18px;">${weather.temp}°F</div>
                <div class="tiny">${esc(weather.condition)} · ${esc(weather.description)}</div>
              </div>
            </div>
          </div>
        `;
      } else if (wbox && OPENWEATHER_API_KEY.includes("YOUR_")) {
        wbox.innerHTML = `<div class="card tiny reveal">Add OpenWeather API key to enable weather.</div>`;
      }
    }

    const alertBox = document.getElementById("alertBox");
    if (alertBox && !jobs.length) {
      showAlert("No jobs yet. Tap + to create your first job.", "info", "alertBox");
    }
  }, 100);
}

function jobCard(j) {
  const icon = SPECIES_ICONS[j.species] || "🐾";
  const statusClass = STATUS_STYLES[j.status] || "active";
  const s = jobScore(j);
  const jobServices = services.filter(s => s.job_id === j.id);
  const totalServices = jobServices.reduce((sum, s) => sum + Number(s.total || 0), 0);

  return `
    <div class="card job">
      <div class="job-header">
        <span class="species-icon">${icon}</span>
        <h3 style="margin:0;flex:1;">${esc(j.customer_name)}</h3>
        <span class="status-pill ${statusClass}">${esc(j.status || "Active")}</span>
      </div>
      <div>${esc(j.address)}</div>
      <div class="tiny">${esc(j.species)} · ${esc(j.town || "")} · ${money(j.grand_total || j.estimate)}</div>
      <div style="margin-top:6px;">
        <span class="pill">${esc(j.town || "Unsorted")}</span>
        <span class="pill muted">${esc(j.assigned_tech || "Unassigned")}</span>
        <span class="pill info">${jobServices.length} services</span>
        ${j.latitude ? '<span class="pill">📍 GPS</span>' : ""}
      </div>
      <div class="prog"><div class="bar" style="width:${s}%"></div></div>
      <div class="tiny">Score ${s}% · Est ${money(j.estimate || 0)} · Services ${money(totalServices)}</div>
      <div class="job-actions">
        <button class="primary" onclick="openJob('${j.id}')">Open</button>
        <button class="secondary" onclick="navigateToJob(${j.latitude || "null"}, ${j.longitude || "null"}, '${esc(j.address)}')">Navigate</button>
      </div>
    </div>
  `;
}

function jobsPage() {
  shell(`
    <div class="search-box">
      <input id="searchInput" placeholder="🔍 Search jobs, customers, addresses, species..." oninput="onSearchInput(this.value)">
    </div>
    <button class="action" onclick="go('new')">➕ New Job</button>
    <div id="jobList">${jobs.map(jobCard).join("") || `<div class="card">No jobs yet.</div>`}</div>
  `);
}

window.onSearchInput = debounce(function (q) {
  const list = document.getElementById("jobList");
  if (!list) return;
  const term = q.toLowerCase();
  const filtered = jobs.filter(j =>
    (j.customer_name + j.address + j.town + j.species + j.status + (j.notes || "")).toLowerCase().includes(term)
  );
  list.innerHTML = filtered.map(jobCard).join("") || `<div class="card">No matching jobs.</div>`;
  lazyLoadImages();
}, 250);

window.openJob = function (id) {
  selectedJob = jobs.find(j => j.id === id);
  screen = "detail";
  updateBottomNav("detail");
  render();
};

function detailPage() {
  if (!selectedJob) { shell(`<div class="card">No job selected.</div>`); return; }

  const jobServices = services.filter(s => s.job_id === selectedJob.id);
  const jobInspections = inspections.filter(i => i.job_id === selectedJob.id);
  const jobPhotos = photos.filter(p => p.job_id === selectedJob.id);
  const totalServices = jobServices.reduce((sum, s) => sum + Number(s.total || 0), 0);
  const icon = SPECIES_ICONS[selectedJob.species] || "🐾";
  const statusClass = STATUS_STYLES[selectedJob.status] || "active";
  const s = jobScore(selectedJob);

  shell(`
    <div class="card stack">
      <div class="job-header">
        <span class="species-icon">${icon}</span>
        <h2 style="margin:0;flex:1;">${esc(selectedJob.customer_name)}</h2>
        <span class="status-pill ${statusClass}">${esc(selectedJob.status || "Active")}</span>
      </div>
      <div>${esc(selectedJob.address)}${selectedJob.town ? ", " + esc(selectedJob.town) : ""}</div>
      <div class="tiny">${formatPhone(selectedJob.phone) || esc(selectedJob.phone || "")} · ${esc(selectedJob.species)} · ${esc(selectedJob.email || "")}</div>
      <div class="tiny">Estimate: ${money(selectedJob.estimate)} · Tax: ${money(selectedJob.tax_amount)} · Total: ${money(selectedJob.grand_total)}</div>
      <div class="prog"><div class="bar" style="width:${s}%"></div></div>
      <div class="tiny">Job Score ${s}%</div>

      <div class="job-actions" style="margin-top:14px;">
        <button class="primary" onclick="saveGps('${selectedJob.id}')">📌 Save GPS</button>
        <button class="secondary" onclick="navigateToJob(${selectedJob.latitude || "null"}, ${selectedJob.longitude || "null"}, '${esc(selectedJob.address)}')">🚗 Navigate</button>
      </div>
      <button class="action dark" style="margin-top:8px;" onclick="createCalendarEvent(${JSON.stringify(selectedJob).replace(/"/g, '&quot;')})">📅 Add to Google Calendar</button>
      <button class="action dark" style="margin-top:8px;" onclick="generateJobPDF()">📄 Download Job PDF</button>
    </div>

    <div id="weatherBox"></div>

    <div id="detailMap" style="height:280px;width:100%;border-radius:16px;margin-top:12px;border:1px solid var(--border);background:var(--card);"></div>

    <div class="card">
      <h3>Add Service</h3>
      <select id="serviceName" onchange="servicePrice.value=this.selectedOptions[0].dataset.price">
        ${SERVICES.map(s => `<option data-price="${s.price}">${s.name}</option>`).join("")}
      </select>
      <input id="serviceQty" type="number" value="1" placeholder="Qty / feet / units">
      <input id="servicePrice" type="number" value="${SERVICES[0].price}" placeholder="Unit price">
      <button class="action" onclick="addService('${selectedJob.id}')">Save Service</button>
    </div>

    <div class="card">
      <h3>Tax</h3>
      <input id="jobTaxRate" type="number" value="${selectedJob.tax_rate || 0}" placeholder="Tax rate %">
      <button class="action" onclick="applyTax('${selectedJob.id}')">Apply Tax To Estimate</button>
    </div>

    <div class="card">
      <h3>Inspection Notes</h3>
      <select id="inspectionType">
        <option>Initial inspection</option>
        <option>Roofline inspection</option>
        <option>Attic inspection</option>
        <option>Crawlspace inspection</option>
        <option>Exterior inspection</option>
        <option>Warranty inspection</option>
      </select>
      <textarea id="inspectionNotes" placeholder="Inspection notes"></textarea>
      <button class="action" onclick="saveInspection('${selectedJob.id}')">Save Inspection Notes</button>

    </div>

    <div class="card">
      <h3>Inspection Photography</h3>
      <input id="photoFile" type="file" accept="image/*">
      <select id="photoTag">
        <option>Inspection photo</option>
        <option>Entry point</option>
        <option>Damage</option>
        <option>Droppings / evidence</option>
        <option>Repair before</option>
        <option>Repair after</option>
      </select>
      <textarea id="photoNotes" placeholder="Photo notes"></textarea>
      <button class="action" onclick="saveInspectionPhoto('${selectedJob.id}')">Save Inspection Photo</button>
    </div>

    <div class="card">
      <h3>Services Total: ${money(totalServices)}</h3>
      ${jobServices.map(s => `
        <div class="service">
          <strong>${esc(s.service)}</strong><br>
          ${s.qty} × ${money(s.unit_price)} = ${money(s.total)}
        </div>
      `).join("") || `<div class="tiny">No services added yet.</div>`}
    </div>

    <div class="card">
      <h3>Inspection History</h3>
      ${jobInspections.map(i => `
        <div class="service">
          <strong>${esc(i.inspection_type)}</strong>
          <div class="tiny">${esc(i.created_at)}</div>
          <div>${esc(i.notes)}</div>
        </div>
      `).join("") || `<div class="tiny">No inspections yet.</div>`}
    </div>

    <div class="card">
      <h3>Photos</h3>
      ${jobPhotos.map(p => `
        <div class="service">
          <strong>${esc(p.tag)}</strong>
          <div class="tiny">${esc(p.notes)}</div>
          ${p.image_url ? `<img class="photo lazy" data-src="${p.image_url}" alt="${esc(p.tag)}">` : ""}
        </div>
      `).join("") || `<div class="tiny">No photos yet.</div>`}
    </div>
  `);

  setTimeout(async () => {
    if (selectedJob.latitude && selectedJob.longitude) {
      if (window.google?.maps) {
        const dmap = initMap("detailMap");
        if (dmap) {
          const pos = { lat: parseFloat(selectedJob.latitude), lng: parseFloat(selectedJob.longitude) };
          dmap.setCenter(pos);
          dmap.setZoom(16);
          new google.maps.Marker({ position: pos, map: dmap, title: esc(selectedJob.customer_name) });
        }
      }

      const weather = await getWeather(selectedJob.latitude, selectedJob.longitude);
      const wbox = document.getElementById("weatherBox");
      if (wbox && weather) {
        wbox.innerHTML = `
          <div class="card">
            <div class="weather-card">
              <img src="${weather.icon}" alt="${esc(weather.description)}" style="width:48px;height:48px;">
              <div>
                <div style="font-weight:700;font-size:18px;">${weather.temp}°F</div>
                <div class="tiny">${esc(weather.condition)} · ${esc(weather.description)}</div>
              </div>
            </div>
          </div>
        `;
      }
    }
  }, 100);
}

function newJobPage() {
  shell(`
    <div class="card">
      <h2>New Job</h2>
      <input id="customer" placeholder="Customer name *">
      <input id="phone" placeholder="Phone (e.g. 555-123-4567)">
      <input id="email" placeholder="Email">
      <input id="address" placeholder="Address *">
      <input id="town" placeholder="Town">
      <select id="species">${SPECIES.map(s => `<option>${s}</option>`).join("")}</select>
      <select id="assignedTech">
        <option value="">Unassigned</option>
        ${techs.map(t => `<option>${esc(t.name)}</option>`).join("")}
      </select>
      <textarea id="notes" placeholder="Notes / scope"></textarea>
      <button class="action" onclick="createJob()">Save Job</button>

    </div>
  `);
}

window.createJob = async function () {
  const payload = {
    customer_name: document.getElementById("customer").value.trim(),
    phone: document.getElementById("phone").value.trim(),
    email: document.getElementById("email").value.trim(),
    address: document.getElementById("address").value.trim(),
    town: document.getElementById("town").value.trim(),
    species: document.getElementById("species").value,
    status: "Active",
    assigned_tech: document.getElementById("assignedTech").value,
    notes: document.getElementById("notes").value.trim(),
    estimate: 0,
    tax_rate: 0,
    tax_amount: 0,
    grand_total: 0
  };

  const errors = validateJob(payload);
  if (errors.length) { showToast(errors.join("; "), "error", 5000); return; }

  showLoading("Saving job…");
  try {
    const { error } = await supabase.from("jobs").insert(payload);
    if (error) throw error;
    showToast("Job created");
    await loadData();
    go("jobs");
  } catch (err) {
    showToast(err.message || "Save failed", "error");
  } finally {
    hideLoading();
  }
};

window.addService = async function (jobId) {
  const qty = Number(document.getElementById("serviceQty").value || 1);
  const price = Number(document.getElementById("servicePrice").value || 0);
  const total = qty * price;

  showLoading("Saving service…");
  try {
    const { error } = await supabase.from("services").insert({
      job_id: jobId,
      service: document.getElementById("serviceName").value,
      qty,
      unit_price: price,
      total
    });
    if (error) throw error;
    await updateJobEstimate(jobId);
    await loadData();
    showToast("Service added");
  } catch (err) {
    showToast(err.message || "Failed to add service", "error");
  } finally {
    hideLoading();
  }
};

async function updateJobEstimate(jobId) {
  const { data } = await supabase.from("services").select("*").eq("job_id", jobId);
  const subtotal = (data || []).reduce((sum, s) => sum + Number(s.total || 0), 0);
  const job = jobs.find(j => j.id === jobId);
  const taxRate = Number(job?.tax_rate || 0);
  const taxAmount = +(subtotal * (taxRate / 100)).toFixed(2);
  const grandTotal = +(subtotal + taxAmount).toFixed(2);

  await supabase.from("jobs").update({
    estimate: subtotal,
    tax_amount: taxAmount,
    grand_total: grandTotal
  }).eq("id", jobId);
}

window.applyTax = async function (jobId) {
  showLoading("Applying tax…");
  try {
    const taxRate = Number(document.getElementById("jobTaxRate").value || 0);
    const job = jobs.find(j => j.id === jobId);
    const subtotal = Number(job?.estimate || 0);
    const taxAmount = +(subtotal * (taxRate / 100)).toFixed(2);
    const grandTotal = +(subtotal + taxAmount).toFixed(2);

    const { error } = await supabase.from("jobs").update({
      tax_rate: taxRate,
      tax_amount: taxAmount,
      grand_total: grandTotal
    }).eq("id", jobId);

    if (error) throw error;
    await loadData();
    showToast("Tax applied");
  } catch (err) {
    showToast(err.message || "Failed to apply tax", "error");
  } finally {
    hideLoading();
  }
};

window.saveInspection = async function (jobId) {
  showLoading("Saving inspection…");
  try {
    const { error } = await supabase.from("inspections").insert({
      job_id: jobId,
      inspection_type: document.getElementById("inspectionType").value,
      notes: document.getElementById("inspectionNotes").value
    });
    if (error) throw error;
    await loadData();
    showToast("Inspection saved");
  } catch (err) {
    showToast(err.message || "Failed to save inspection", "error");
  } finally {
    hideLoading();
  }
};

window.saveInspectionPhoto = async function (jobId) {
  const file = document.getElementById("photoFile").files[0];
  if (!file) { showToast("Choose a photo.", "warn"); return; }

  showLoading("Compressing & uploading…");
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const compressed = await compressImage(reader.result, 1200, 0.7);
      const { error } = await supabase.from("photos").insert({
        job_id: jobId,
        image_url: compressed,
        tag: document.getElementById("photoTag").value,
        notes: document.getElementById("photoNotes").value
      });
      if (error) throw error;
      await loadData();
      showToast("Photo saved");
    } catch (err) {
      showToast(err.message || "Upload failed", "error");
    } finally {
      hideLoading();
    }
  };
  reader.readAsDataURL(file);
};

function estimatePage() {
  shell(`
    <div class="card">
      <h2>Smart Estimator</h2>

      <select id="estService" onchange="estPrice.value=this.selectedOptions[0].dataset.price; calcEstimate()">
        ${SERVICES.map(s => `<option data-price="${s.price}">${s.name}</option>`).join("")}
      </select>

      <input id="estQty" type="number" value="1" oninput="calcEstimate()" placeholder="Qty / feet / units">
      <input id="estPrice" type="number" value="${SERVICES[0].price}" oninput="calcEstimate()" placeholder="Unit price">
      <input id="estTax" type="number" value="0" oninput="calcEstimate()" placeholder="Tax rate %">

      <textarea id="estimateOut" readonly></textarea>

      <button class="action" onclick="calcEstimate()">Calculate</button>
      <button class="action dark" onclick="emailEstimate()">Open Gmail Estimate</button>
      <button class="action" onclick="generateEstimatePDF()">📄 Download PDF</button>
    </div>
  `);
  setTimeout(() => calcEstimate(), 50);
}

window.calcEstimate = function () {
  const subtotal = Number(document.getElementById("estQty").value || 0) * Number(document.getElementById("estPrice").value || 0);
  const taxRate = Number(document.getElementById("estTax").value || 0);
  const taxAmount = +(subtotal * (taxRate / 100)).toFixed(2);
  const total = +(subtotal + taxAmount).toFixed(2);

  document.getElementById("estimateOut").value =
    `Wildlife Whisperer LLC Estimate\n\n` +
    `Service: ${document.getElementById("estService").value}\n` +
    `Quantity: ${document.getElementById("estQty").value}\n` +
    `Unit Price: ${money(document.getElementById("estPrice").value)}\n\n` +
    `Subtotal: ${money(subtotal)}\n` +
    `Tax Rate: ${taxRate}%\n` +
    `Tax Amount: ${money(taxAmount)}\n\n` +
    `Recommended Total: ${money(total)}\n\n` +
    `Scope includes professional nuisance wildlife inspection, inspection photography when selected, exclusion work, repair materials, service documentation, and warranty boundaries.`;
};

window.emailEstimate = function () {
  const out = document.getElementById("estimateOut");
  if (!out.value) calcEstimate();
  const subject = encodeURIComponent("Wildlife Whisperer LLC Estimate");
  const body = encodeURIComponent(out.value);
  window.location.href = `mailto:?subject=${subject}&body=${body}`;
};

window.generateEstimatePDF = function () {
  const out = document.getElementById("estimateOut");
  if (!out.value) calcEstimate();
  const doc = new jsPDF();
  doc.setFontSize(18);
  doc.text("Wildlife Whisperer LLC", 20, 20);
  doc.setFontSize(14);
  doc.text("Estimate", 20, 30);
  doc.setFontSize(11);
  const lines = doc.splitTextToSize(out.value, 170);
  doc.text(lines, 20, 45);
  doc.save("wildlife-estimate.pdf");
};

window.generateJobPDF = function () {
  if (!selectedJob) return showToast("No job selected.", "warn");
  const doc = new jsPDF();
  doc.setFontSize(18);
  doc.text("Wildlife Whisperer LLC", 20, 20);
  doc.setFontSize(14);
  doc.text("Job Report", 20, 30);
  doc.setFontSize(11);

  const jobServices = services.filter(s => s.job_id === selectedJob.id);
  const totalServices = jobServices.reduce((sum, s) => sum + Number(s.total || 0), 0);

  let y = 45;
  const addLine = (label, value) => {
    doc.setFont(undefined, "bold");
    doc.text(label + ":", 20, y);
    doc.setFont(undefined, "normal");
    const lines = doc.splitTextToSize(String(value || "N/A"), 120);
    doc.text(lines, 70, y);
    y += 6 * lines.length;
    if (y > 270) { doc.addPage(); y = 20; }
  };

  addLine("Customer", selectedJob.customer_name);
  addLine("Address", selectedJob.address);
  addLine("Phone", selectedJob.phone);
  addLine("Species", selectedJob.species);
  addLine("Status", selectedJob.status);
  addLine("Town", selectedJob.town);
  addLine("Assigned Tech", selectedJob.assigned_tech);
  addLine("Estimate", money(selectedJob.estimate));
  addLine("Tax", money(selectedJob.tax_amount));
  addLine("Total", money(selectedJob.grand_total));
  addLine("Services Total", money(totalServices));
  addLine("Notes", selectedJob.notes);

  doc.save(`job-${selectedJob.customer_name.replace(/[^a-z0-9]/gi, "_")}.pdf`);
};

function techsPage() {
  shell(`
    <div class="card">
      <h2>Add Tech</h2>
      <input id="techName" placeholder="Name">
      <input id="techPhone" placeholder="Phone">
      <input id="techRole" placeholder="Role">
      <button class="action" onclick="addTech()">Save Tech</button>
    </div>

    ${techs.map(t => `
      <div class="card">
        <strong>${esc(t.name)}</strong>
        <div class="tiny">${formatPhone(t.phone) || esc(t.phone || "")} · ${esc(t.role || "")}</div>
      </div>
    `).join("")}
  `);
}

window.addTech = async function () {
  const payload = {
    name: document.getElementById("techName").value.trim(),
    phone: document.getElementById("techPhone").value.trim(),
    role: document.getElementById("techRole").value.trim()
  };

  const errors = validateTech(payload);
  if (errors.length) { showToast(errors.join("; "), "error", 5000); return; }

  showLoading("Saving tech…");
  try {
    const { error } = await supabase.from("techs").insert(payload);
    if (error) throw error;
    await loadData();
    go("techs");
    showToast("Tech added");
  } catch (err) {
    showToast(err.message || "Failed to add tech", "error");
  } finally {
    hideLoading();
  }
};

function aiPage() {
  shell(`
    <div class="card">
      <h2>🧠 Kimi AI Field Assistant</h2>
      <select id="aiMode">
        <option value="field_plan">Field Plan</option>
        <option value="job_notes">Job Notes</option>
        <option value="estimate">Estimate Guidance</option>
        <option value="customer_message">Customer Message</option>
        <option value="invoice_notes">Invoice Notes</option>
        <option value="risk_check">Risk / Safety Check</option>
      </select>
      <select id="aiSpecies">${SPECIES.map(s => `<option>${s}</option>`).join("")}</select>
      <textarea id="aiObs" rows="6" placeholder="Example: raccoon entry near soffit, attic droppings, customer hears noise at night..."></textarea>
      <button class="action" onclick="aiSuggest()">Generate Kimi AI Plan</button>

      <textarea id="aiOut" rows="14" placeholder="AI output appears here..."></textarea>
    </div>
  `);
}

window.aiSuggest = async function () {
  const mode = document.getElementById("aiMode")?.value || "field_plan";
  const species = document.getElementById("aiSpecies")?.value || selectedJob?.species || "";
  const observation = document.getElementById("aiObs")?.value || selectedJob?.notes || "";

  const jobServices = selectedJob ? services.filter(s => s.job_id === selectedJob.id) : [];

  showLoading("Running Kimi AI assistant…");

  try {
    const result = await runFieldAI(supabase, {
      mode,
      species,
      observation,
      job: selectedJob || { species, notes: observation },
      services: jobServices,
      businessContext: "Wildlife Whisperer nuisance wildlife removal field app. Prioritize inspection notes, exclusion planning, estimate clarity, customer communication, safety reminders, and professional documentation."
    });

    const formatted = formatFieldAIResult(result);
    const out = document.getElementById("aiOut");
    if (out) out.value = formatted;

    if (selectedJob?.id) {
      await supabase.from("jobs").update({
        ai_notes: formatted,
        ai_customer_message: result.customer_message || null,
        ai_invoice_notes: result.invoice_notes || null,
        ai_last_run_at: new Date().toISOString()
      }).eq("id", selectedJob.id);

      await supabase.from("ai_runs").insert({
        job_id: selectedJob.id,
        mode,
        input: { species, observation, services: jobServices },
        output: result,
        provider: "kimi_moonshot"
      });
    }

    showToast("Kimi AI assistant complete");
  } catch (err) {
    console.error(err);
    showToast(err.message || "Kimi AI assistant failed", "error", 6000);
  } finally {
    hideLoading();
  }
};

window.saveGps = async function (jobId) {
  showLoading("Getting GPS…");
  try {
    const pos = await getCurrentPosition();
    const { error } = await supabase.from("jobs").update({ latitude: pos.latitude, longitude: pos.longitude }).eq("id", jobId);
    if (error) throw error;
    showToast("GPS saved to job");
    await loadData();
  } catch (err) {
    showToast(err.message || "GPS error", "error");
  } finally {
    hideLoading();
  }
};

/* ─── EXPORT / IMPORT ─── */
window.exportData = function () {
  const data = { jobs, techs, services, inspections, photos, exportedAt: new Date().toISOString() };
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
  a.download = `wildlife-fieldops-backup-${new Date().toISOString().slice(0,10)}.json`;
  a.click();
};

window.importDataPrompt = function () {
  const raw = prompt("Paste JSON backup data:");
  if (!raw) return;
  importData(raw);
};

window.importData = async function (raw) {
  showLoading("Importing…");
  try {
    const data = JSON.parse(raw);
    if (!data.jobs) { showToast("Invalid format: missing jobs array.", "error"); return; }

    if (data.jobs?.length) {
      const { error } = await supabase.from("jobs").upsert(data.jobs);
      if (error) console.error("Jobs import error:", error);
    }
    if (data.techs?.length) {
      const { error } = await supabase.from("techs").upsert(data.techs);
      if (error) console.error("Techs import error:", error);
    }
    if (data.services?.length) {
      const { error } = await supabase.from("services").upsert(data.services);
      if (error) console.error("Services import error:", error);
    }
    if (data.inspections?.length) {
      const { error } = await supabase.from("inspections").upsert(data.inspections);
      if (error) console.error("Inspections import error:", error);
    }
    if (data.photos?.length) {
      const { error } = await supabase.from("photos").upsert(data.photos);
      if (error) console.error("Photos import error:", error);
    }

    showToast("Import complete — reloading data…");
    await loadData();
  } catch (e) {
    showToast("Import failed: " + e.message, "error");
  } finally {
    hideLoading();
  }
};

function metricsPage() {
  const activeJobs = jobs.filter(j => j.status !== "Closed");
  const closedJobs = jobs.filter(j => j.status === "Closed");
  const totalRevenue = jobs.reduce((sum, j) => sum + Number(j.grand_total || 0), 0);

  const speciesCounts = {};
  jobs.forEach(j => { if (j.species) speciesCounts[j.species] = (speciesCounts[j.species] || 0) + 1; });
  const maxSpeciesCount = Math.max(...Object.values(speciesCounts), 1);

  const statusCounts = {};
  jobs.forEach(j => { statusCounts[j.status || "Active"] = (statusCounts[j.status || "Active"] || 0) + 1; });

  const techRevenue = {};
  techs.forEach(t => techRevenue[t.name] = 0);
  jobs.forEach(j => { if (j.assigned_tech && techRevenue.hasOwnProperty(j.assigned_tech)) techRevenue[j.assigned_tech] += Number(j.grand_total || 0); });
  const maxTechRevenue = Math.max(...Object.values(techRevenue), 1);

  const townCounts = {};
  jobs.forEach(j => { if (j.town) townCounts[j.town] = (townCounts[j.town] || 0) + 1; });
  const maxTownCount = Math.max(...Object.values(townCounts), 1);

  shell(`
    <div class="card">
      <h2>📊 Business Metrics</h2>
      <div class="grid">
        <div class="card"><div class="stat">${activeJobs.length}</div><div class="tiny">Active Jobs</div></div>
        <div class="card"><div class="stat">${closedJobs.length}</div><div class="tiny">Closed Jobs</div></div>
        <div class="card"><div class="stat">${jobs.length}</div><div class="tiny">Total Jobs</div></div>
        <div class="card"><div class="stat">${money(totalRevenue)}</div><div class="tiny">Total Revenue</div></div>
      </div>
    </div>

    <div class="card">
      <h3>Jobs by Species</h3>
      ${Object.entries(speciesCounts).sort((a, b) => b[1] - a[1]).map(([species, count]) => `
        <div style="margin:8px 0;">
          <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;">
            <span>${esc(species)}</span>
            <span>${count}</span>
          </div>
          <div class="prog"><div class="bar" style="width:${(count / maxSpeciesCount * 100)}%"></div></div>
        </div>
      `).join("") || '<div class="tiny">No species data.</div>'}
    </div>

    <div class="card">
      <h3>Jobs by Status</h3>
      ${Object.entries(statusCounts).map(([status, count]) => `
        <div style="margin:8px 0;">
          <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;">
            <span>${esc(status)}</span>
            <span>${count}</span>
          </div>
          <div class="prog"><div class="bar" style="width:${jobs.length ? (count / jobs.length * 100) : 0}%"></div></div>
        </div>
      `).join("") || '<div class="tiny">No status data.</div>'}
    </div>

    <div class="card">
      <h3>Tech Revenue</h3>
      ${Object.entries(techRevenue).sort((a, b) => b[1] - a[1]).map(([name, revenue]) => `
        <div style="margin:8px 0;">
          <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;">
            <span>${esc(name)}</span>
            <span>${money(revenue)}</span>
          </div>
          <div class="prog"><div class="bar" style="width:${(revenue / maxTechRevenue * 100)}%"></div></div>
        </div>
      `).join("") || '<div class="tiny">No tech data.</div>'}
    </div>

    <div class="card">
      <h3>Jobs by Town</h3>
      ${Object.entries(townCounts).sort((a, b) => b[1] - a[1]).map(([town, count]) => `
        <div style="margin:8px 0;">
          <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;">
            <span>${esc(town)}</span>
            <span>${count}</span>
          </div>
          <div class="prog"><div class="bar" style="width:${(count / maxTownCount * 100)}%"></div></div>
        </div>
      `).join("") || '<div class="tiny">No town data.</div>'}
    </div>
  `);
}

/* ─── RENDER ─── */
function render() {
  nav();
  if (screen === "dashboard") dashboard();
  if (screen === "jobs") jobsPage();
  if (screen === "detail") detailPage();
  if (screen === "new") newJobPage();
  if (screen === "estimate") estimatePage();
  if (screen === "techs") techsPage();
  if (screen === "metrics") metricsPage();
  if (screen === "ai") aiPage();
}

/* ─── INIT ─── */
function hideSplash() {
  const sp = document.getElementById("splash");
  if (sp) {
    sp.classList.add("hidden");
    setTimeout(() => sp.remove(), 600);
  }
}

initTheme();
loadGoogleMaps();
loadGoogleCalendarAPI();
loadData();
setTimeout(hideSplash, 1500);
window.closeModal = closeModal;

/* ─── SERVICE WORKER UPDATE ─── */
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js").then(reg => {
    reg.addEventListener("updatefound", () => {
      const newWorker = reg.installing;
      newWorker.addEventListener("statechange", () => {
        if (newWorker.state === "installed" && navigator.serviceWorker.controller) {
          showToast("App update available — reloading…", "success");
          setTimeout(() => location.reload(), 1500);
        }
      });
    });
  }).catch(() => {});
}
